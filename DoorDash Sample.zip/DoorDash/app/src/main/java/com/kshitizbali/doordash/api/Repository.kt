package com.kshitizbali.doordash.api

import android.util.Log
import com.kshitizbali.doordash.api.ApiClient.Companion.callApi
import com.kshitizbali.doordash.model.Restaurant
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

/**
 * A Repo of functions where we create request for fetching data
 * from the APis
 */
class Repository {

    companion object {
        /**
         * We request for restaurant list based on location (most important)
         * ,offset and limit
         * @param lat A [String] which is the latitude of the location
         * @param lng A [String] which is the longitude of the location
         * @param offset  A [String] which is the offset
         * @param limit  A [String] which specifies the limit of restaurants we receive as
         * a response.
         */
        fun getRestaurantList(
            lat: String,
            lng: String,
            offset: String,
            limit: String,
            callback: RestaurantListInterface
        ) {
            val apiCall = callApi();

            apiCall.getRestaurantsList(lat, lng, offset, limit)
                .enqueue(object : Callback<com.kshitizbali.doordash.model.RestaurantList?> {
                    override fun onResponse(
                        call: Call<com.kshitizbali.doordash.model.RestaurantList?>,
                        response: Response<com.kshitizbali.doordash.model.RestaurantList?>
                    ) {
                        response.isSuccessful.let {
                            Log.i("response",""+response);
                            if (response.body() != null) {
                                Log.i("response body",""+response.body());
                                callback.onRestListFetched(response.body());
                            }
                        }
                    }

                    override fun onFailure(
                        call: Call<com.kshitizbali.doordash.model.RestaurantList?>,
                        t: Throwable
                    ) {
                        Log.e("getRestList Error", "Error getting rest list " + t.message);
                    }
                })
        }

        /**
         * We get a specific restaurant based on a restaurant id.
         * @param id A  [String] specifying restaurant ID
         */
        fun getRestaurantById(id: String, callback: RestaurantInterface){
            val apiCall = callApi();
            apiCall.getRestaurant(id).enqueue(object : Callback<Restaurant> {
                override fun onResponse(call: Call<Restaurant>, response: Response<Restaurant>) {
                    response.isSuccessful.let {
                        Log.i("response",""+response);
                        if (response.body() != null){
                            Log.i("response body",""+response.body());
                            callback.onRestaurantDataFetched(response.body());
                        }
                    }
                }

                override fun onFailure(call: Call<Restaurant>, t: Throwable) {
                    Log.e("getRestById Error", "Error getting rest info " + t.message);
                }

            })
        }
    }

    /**
     * Interface callback for RestaurantList
     */
    interface RestaurantListInterface {
        fun onRestListFetched(data: com.kshitizbali.doordash.model.RestaurantList?)
    }
    /**
     * Interface callback for Restaurant
     */
    interface RestaurantInterface {
        fun onRestaurantDataFetched(data: com.kshitizbali.doordash.model.Restaurant?)
    }
}