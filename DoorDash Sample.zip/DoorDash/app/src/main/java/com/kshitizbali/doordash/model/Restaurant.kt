package com.kshitizbali.doordash.model

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

/**
 * A model class created from a Restaurant json response
 */
class Restaurant {

    @SerializedName("phone_number")
    @Expose
    var phoneNumber: String? = null

    @SerializedName("yelp_review_count")
    @Expose
    var yelpReviewCount = 0

    @SerializedName("is_consumer_subscription_eligible")
    @Expose
    var isIsConsumerSubscriptionEligible = false
        private set

    @SerializedName("offers_delivery")
    @Expose
    var isOffersDelivery = false

    @SerializedName("max_order_size")
    @Expose
    var maxOrderSize: Any? = null

    @SerializedName("delivery_fee")
    @Expose
    var deliveryFee = 0

    @SerializedName("max_composite_score")
    @Expose
    var maxCompositeScore = 0

    @SerializedName("provides_external_courier_tracking")
    @Expose
    var isProvidesExternalCourierTracking = false

    @SerializedName("id")
    @Expose
    var id = 0

    @SerializedName("average_rating")
    @Expose
    var averageRating = 0f

    @SerializedName("tags")
    @Expose
    var tags: List<String>? = null

    @SerializedName("delivery_radius")
    @Expose
    var deliveryRadius = 0

    @SerializedName("inflation_rate")
    @Expose
    var inflationRate = 0f

    @SerializedName("menus")
    @Expose
    var menus: List<Menu>? = null

    @SerializedName("show_store_menu_header_photo")
    @Expose
    var isShowStoreMenuHeaderPhoto = false

    @SerializedName("composite_score")
    @Expose
    var compositeScore = 0

    @SerializedName("fulfills_own_deliveries")
    @Expose
    var isFulfillsOwnDeliveries = false

    @SerializedName("offers_pickup")
    @Expose
    var isOffersPickup = false

    @SerializedName("number_of_ratings")
    @Expose
    var numberOfRatings = 0

    @SerializedName("status_type")
    @Expose
    var statusType: String? = null

    @SerializedName("is_only_catering")
    @Expose
    var isIsOnlyCatering = false
        private set

    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("delivery_fee_details")
    @Expose
    var deliveryFeeDetails: DeliveryFeeDetails? = null

    @SerializedName("object_type")
    @Expose
    var objectType: String? = null

    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("business")
    @Expose
    var business: Business? = null

    @SerializedName("yelp_biz_id")
    @Expose
    var yelpBizId: String? = null

    @SerializedName("asap_time")
    @Expose
    var asapTime: Any? = null

    @SerializedName("should_show_store_logo")
    @Expose
    var isShouldShowStoreLogo = false

    @SerializedName("yelp_rating")
    @Expose
    var yelpRating = 0f

    @SerializedName("extra_sos_delivery_fee")
    @Expose
    var extraSosDeliveryFee = 0

    @SerializedName("business_id")
    @Expose
    var businessId = 0

    @SerializedName("special_instructions_max_length")
    @Expose
    var specialInstructionsMaxLength: Any? = null

    @SerializedName("cover_img_url")
    @Expose
    var coverImgUrl: String? = null

    @SerializedName("address")
    @Expose
    var address: Address? = null

    @SerializedName("price_range")
    @Expose
    var priceRange = 0

    @SerializedName("slug")
    @Expose
    var slug: String? = null

    @SerializedName("show_suggested_items")
    @Expose
    var isShowSuggestedItems = false

    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("is_newly_added")
    @Expose
    var isIsNewlyAdded = false
        private set

    @SerializedName("is_good_for_group_orders")
    @Expose
    var isIsGoodForGroupOrders = false
        private set

    @SerializedName("service_rate")
    @Expose
    var serviceRate = 0f

    @SerializedName("merchant_promotions")
    @Expose
    var merchantPromotions: List<MerchantPromotion>? = null

    @SerializedName("header_image_url")
    @Expose
    var headerImageUrl: Any? = null

    fun setIsConsumerSubscriptionEligible(isConsumerSubscriptionEligible: Boolean) {
        isIsConsumerSubscriptionEligible = isConsumerSubscriptionEligible
    }

    fun setIsOnlyCatering(isOnlyCatering: Boolean) {
        isIsOnlyCatering = isOnlyCatering
    }

    fun setIsNewlyAdded(isNewlyAdded: Boolean) {
        isIsNewlyAdded = isNewlyAdded
    }

    fun setIsGoodForGroupOrders(isGoodForGroupOrders: Boolean) {
        isIsGoodForGroupOrders = isGoodForGroupOrders
    }


    class Address {
        @SerializedName("city")
        @Expose
        var city: String? = null

        @SerializedName("subpremise")
        @Expose
        var subpremise: String? = null

        @SerializedName("id")
        @Expose
        var id = 0

        @SerializedName("printable_address")
        @Expose
        var printableAddress: String? = null

        @SerializedName("state")
        @Expose
        var state: String? = null

        @SerializedName("street")
        @Expose
        var street: String? = null

        @SerializedName("country")
        @Expose
        var country: String? = null

        @SerializedName("lat")
        @Expose
        var lat = 0f

        @SerializedName("lng")
        @Expose
        var lng = 0f

        @SerializedName("shortname")
        @Expose
        var shortname: String? = null

        @SerializedName("zip_code")
        @Expose
        var zipCode: String? = null
    }

    class Amount {
        @SerializedName("currency")
        @Expose
        var currency: String? = null

        @SerializedName("display_string")
        @Expose
        var displayString: String? = null

        @SerializedName("unit_amount")
        @Expose
        var unitAmount = 0
    }

    class Business {
        @SerializedName("business_vertical")
        @Expose
        var businessVertical: Any? = null

        @SerializedName("id")
        @Expose
        var id = 0

        @SerializedName("name")
        @Expose
        var name: String? = null
    }

    class DeliveryFeeDetails {
        @SerializedName("final_fee")
        @Expose
        var finalFee: FinalFee? = null

        @SerializedName("discount")
        @Expose
        var discount: Discount? = null

        @SerializedName("surge_fee")
        @Expose
        var surgeFee: SurgeFee? = null

        @SerializedName("original_fee")
        @Expose
        var originalFee: OriginalFee? = null
    }

    class DeliveryFeeMonetaryFields {
        @SerializedName("currency")
        @Expose
        var currency: String? = null

        @SerializedName("display_string")
        @Expose
        var displayString: String? = null

        @SerializedName("unit_amount")
        @Expose
        var unitAmount = 0

        @SerializedName("decimal_places")
        @Expose
        var decimalPlaces = 0
    }

    class Discount {
        @SerializedName("description")
        @Expose
        var description: String? = null

        @SerializedName("source_type")
        @Expose
        var sourceType: String? = null

        @SerializedName("text")
        @Expose
        var text: String? = null

        @SerializedName("discount_type")
        @Expose
        var discountType: String? = null

        @SerializedName("amount")
        @Expose
        var amount: Amount? = null

        @SerializedName("min_subtotal")
        @Expose
        var minSubtotal: MinSubtotal? = null
    }


    class FinalFee {
        @SerializedName("display_string")
        @Expose
        var displayString: String? = null

        @SerializedName("unit_amount")
        @Expose
        var unitAmount = 0
    }

    class Menu {
        @SerializedName("status")
        @Expose
        var status: String? = null

        @SerializedName("menu_version")
        @Expose
        var menuVersion = 0

        @SerializedName("subtitle")
        @Expose
        var subtitle: String? = null

        @SerializedName("name")
        @Expose
        var name: String? = null

        @SerializedName("open_hours")
        @Expose
        var openHours: List<List<OpenHour>>? = null

        @SerializedName("is_business_enabled")
        @Expose
        var isBusinessEnabled: Any? = null

        @SerializedName("is_catering")
        @Expose
        var isIsCatering = false
            private set

        @SerializedName("id")
        @Expose
        var id = 0

        @SerializedName("status_type")
        @Expose
        var statusType: String? = null

        fun setIsCatering(isCatering: Boolean) {
            isIsCatering = isCatering
        }
    }

    class MerchantPromotion {
        @SerializedName("minimum_subtotal_monetary_fields")
        @Expose
        var minimumSubtotalMonetaryFields: MinimumSubtotalMonetaryFields? = null

        @SerializedName("delivery_fee")
        @Expose
        var deliveryFee = 0

        @SerializedName("delivery_fee_monetary_fields")
        @Expose
        var deliveryFeeMonetaryFields: DeliveryFeeMonetaryFields? = null

        @SerializedName("minimum_subtotal")
        @Expose
        var minimumSubtotal: Any? = null

        @SerializedName("new_store_customers_only")
        @Expose
        var isNewStoreCustomersOnly = false

        @SerializedName("id")
        @Expose
        var id = 0
    }

    class MinSubtotal {
        @SerializedName("currency")
        @Expose
        var currency: String? = null

        @SerializedName("display_string")
        @Expose
        var displayString: String? = null

        @SerializedName("unit_amount")
        @Expose
        var unitAmount = 0
    }

    class MinimumSubtotalMonetaryFields {
        @SerializedName("currency")
        @Expose
        var currency: String? = null

        @SerializedName("display_string")
        @Expose
        var displayString: String? = null

        @SerializedName("unit_amount")
        @Expose
        var unitAmount: Any? = null

        @SerializedName("decimal_places")
        @Expose
        var decimalPlaces = 0
    }


    class OpenHour {
        @SerializedName("hour")
        @Expose
        var hour = 0

        @SerializedName("minute")
        @Expose
        var minute = 0
    }

    class OriginalFee {
        @SerializedName("display_string")
        @Expose
        var displayString: String? = null

        @SerializedName("unit_amount")
        @Expose
        var unitAmount = 0
    }

    class SurgeFee {
        @SerializedName("display_string")
        @Expose
        var displayString: String? = null

        @SerializedName("unit_amount")
        @Expose
        var unitAmount = 0
    }

}

