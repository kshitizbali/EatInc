package com.kshitizbali.doordash.viewmodel

import android.view.View
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kshitizbali.doordash.model.SignUpUserModel

/**
 * Viewmodel for Signup activity
 */
class SignupViewModel : ViewModel() {
    var firstName = MutableLiveData<String>()
    var lastName = MutableLiveData<String>()
    var email = MutableLiveData<String>()
    var phone = MutableLiveData<String>()
    private var signupUserModelMutableLiveData = MutableLiveData<SignUpUserModel>()
    val user: MutableLiveData<SignUpUserModel>?
        get() {
            return signupUserModelMutableLiveData
        }

    fun onClick(view: View?) {
        val signupUserModel =
            SignUpUserModel(firstName.value, lastName.value, email.value, phone.value)
        signupUserModelMutableLiveData.value = signupUserModel
    }
}
