package com.kshitizbali.doordash.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.kshitizbali.doordash.R
import com.kshitizbali.doordash.model.RestaurantList
import com.squareup.picasso.Picasso
import java.math.RoundingMode

class RestaurantListAdapter(
    private val rests: RestaurantList,
    val itemClickListener: OnItemClickListener
) :
    RecyclerView.Adapter<RestaurantListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(
            R.layout.list_rest_item,
            parent,
            false
        )
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(rests, itemClickListener);
    }

    override fun getItemCount(): Int {
        return if (rests.stores.isNullOrEmpty()) {
            0
        } else {
            rests.stores!!.size
        }
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvRestName: TextView
        val tvRestCuisine: TextView
        val tvRestDistance: TextView
        val imageRest: ImageView
        val tvDeliveryTime: TextView
        val tvDeliveryFee: TextView

        init {
            // Define click listener for the ViewHolder's View.
            tvRestName = view.findViewById(R.id.tv_rest_name)
            tvRestCuisine = view.findViewById(R.id.tv_rest_cuisine)
            tvRestDistance = view.findViewById(R.id.tv_distance)
            imageRest = view.findViewById(R.id.image_rest)
            tvDeliveryTime = view.findViewById(R.id.tv_delivery_time)
            tvDeliveryFee = view.findViewById(R.id.tv_delivery_fee)
        }

        fun bind(rests: RestaurantList, clickListener: OnItemClickListener) {
            Picasso.get().load(rests.stores!![adapterPosition].coverImgUrl).into(imageRest)
            tvRestName.text = adapterPosition.plus(1).toString().plus(". ")
                .plus(rests.stores?.get(adapterPosition)?.name)
            tvRestCuisine.text =
                getPriceRange(rests.stores?.get(adapterPosition)?.priceRange.toString())
            tvRestDistance.text =
                rests.stores!![adapterPosition].distanceFromConsumer.toBigDecimal()
                    .setScale(1, RoundingMode.UP).toDouble().toString().plus(" ").plus("mi")
            tvDeliveryTime.text =
                rests.stores!![adapterPosition].status?.asapMinutesRange?.get(0).toString()
                    .plus(" ").plus("min")
            tvDeliveryFee.text = rests.stores!![adapterPosition].displayDeliveryFee
            itemView.setOnClickListener(View.OnClickListener {
                clickListener.onItemClick(rests.stores!![adapterPosition].id.toString());
            })

        }

        private fun getPriceRange(priceRange: String): String {
            if (priceRange == "1") {
                return "$"
            } else if (priceRange == "2") {
                return "$$"
            } else if (priceRange == "3") {
                return "$$$"
            } else if (priceRange == "4") {
                return "$$$$"
            } else if (priceRange == "5") {
                return "$$$$$"
            }
            return ""
        }
    }

    interface OnItemClickListener {
        fun onItemClick(restId: String)
    }

}