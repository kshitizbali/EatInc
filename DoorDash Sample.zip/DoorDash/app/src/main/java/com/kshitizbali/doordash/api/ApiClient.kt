package com.kshitizbali.doordash.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Client for initiating retrofit communication with the API.
 */
class ApiClient {
    companion object {

        //We can change to Rx java
        /**
         * We Get instance of retrofit
         */
        private fun getRetrofit(Url: String): Retrofit {
            return Retrofit.Builder()
                /*.addCallAdapterFactory(
                    RxJava2CallAdapterFactory.create()
                )*/
                .addConverterFactory(
                    GsonConverterFactory.create()
                )
                .baseUrl(Url)
                .build()
        }

        /**
         * We get Retrofit instance with base url
         */
        private fun getApiData(): Retrofit {
            return getRetrofit(Url.BASE_URL)
        }

        /**
         * We create the Api Interface calling using retrofit.
         */
        fun callApi(): ApiInterface {
            val retrofitCall = getApiData()
            return retrofitCall.create(ApiInterface::class.java)
        }

    }

}