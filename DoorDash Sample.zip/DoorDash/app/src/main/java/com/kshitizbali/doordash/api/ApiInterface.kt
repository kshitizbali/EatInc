package com.kshitizbali.doordash.api

import com.kshitizbali.doordash.model.Restaurant
import com.kshitizbali.doordash.model.RestaurantList
import io.reactivex.Observable
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Interface for apis
 */
interface ApiInterface {

    /**
     * We get a complete restaurant list based on location (most important)
     * ,offset and limit
     * @param lat A [String] which is the latitude of the location
     * @param lng A [String] which is the longitude of the location
     * @param offset  A [String] which is the offset
     * @param limit  A [String] which specifies the limit of restaurants we receive as
     * a response.
     */
    @GET("v1/store_feed/?")
    fun getRestaurantsList(
        @Query("lat") lat: String,
        @Query("lng") lng: String,
        @Query("offset") offset: String,
        @Query("limit") limit: String
    ): Call<RestaurantList>

    /**
     * We get a specific restaurant based on a restaurant id.
     * @param id A  [String] specifying restaurant ID
     */
    @GET("v2/restaurant/{id}")
    fun getRestaurant(@Path("id") id: String): Call<Restaurant>


    //We could also use coroutines  and consume this accordingly

    /* @GET("v1/store_feed/?")
     suspend fun getRestaurantsList(
         @Query("lat") lat: String,
         @Query("lng") lng: String,
         @Query("offset") offset: String,
         @Query("limit") limit: String
     ): RestaurantList

     @GET("v2/restaurant/{id}")
     suspend fun getRestaurant(@Path("id") id: String): Restaurant
     @GET("/repositories")*/


    //We could also use RxJava and consume this accordingly

    /*@GET("v1/store_feed/?")
    fun getRestaurantsList(
        @Query("lat") lat: String,
        @Query("lng") lng: String,
        @Query("offset") offset: String,
        @Query("limit") limit: String
    ): Observable<RestaurantList>

    @GET("v2/restaurant/{id}")
    fun getRestaurant(@Path("id") id: String): Observable<Restaurant>*/


}