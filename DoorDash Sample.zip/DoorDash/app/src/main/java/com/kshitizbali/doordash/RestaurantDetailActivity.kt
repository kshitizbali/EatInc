package com.kshitizbali.doordash

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapsInitializer
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.kshitizbali.doordash.api.Repository
import com.kshitizbali.doordash.databinding.ActivityRestaurantDetailBinding
import com.kshitizbali.doordash.model.Restaurant
import com.kshitizbali.doordash.viewmodel.RestaurantViewModel
import com.squareup.picasso.Picasso

/**
 * Restaurant detail activity shows info about a particular restaurant selected from
 * the restaurant list.
 */
class RestaurantDetailActivity : AppCompatActivity(), Repository.RestaurantInterface/*, OnMapReadyCallback*/{

    private lateinit var binding: ActivityRestaurantDetailBinding
    private lateinit var restaurantViewModel: RestaurantViewModel
    private lateinit var phoneNo: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        restaurantViewModel = ViewModelProvider(this).get(
            RestaurantViewModel::class.java
        )

        binding = DataBindingUtil.setContentView(
            this,
            R.layout.activity_restaurant_detail
        )
        binding.lifecycleOwner = this
        binding.restaurantViewModel = restaurantViewModel

        setSupportActionBar(binding.toolbar)
        binding.toolbar.title = ""
        showProgressBar()


        if (intent.extras != null && !intent.extras!!.isEmpty!!) {
            val restId = intent.getStringExtra("REST_ID")
            restaurantViewModel.getRestaurantDetails(restId, this)
        }
    }

    override fun onRestaurantDataFetched(data: Restaurant?) {
        restaurantViewModel.onRestFetched(data)
        phoneNo = data?.phoneNumber.toString()
        Picasso.get().load(data?.coverImgUrl).into(binding.imageRest)
        binding.toolbarLayout.title = restaurantViewModel.restName.value
        binding.fab.setOnClickListener {
            if (restaurantViewModel.phoneNumber.toString().isNotEmpty()){
                val callIntent = Intent(Intent.ACTION_CALL)
                callIntent.data = Uri.parse("tel:$phoneNo") //change the number
                startActivity(callIntent)
            }
        }

        hideProgessBar()
    }

    private fun showProgressBar(){
        binding.progressBarRestSceen.visibility = View.VISIBLE
    }

    private fun hideProgessBar(){
        binding.progressBarRestSceen.visibility = View.GONE
    }

    /*override fun onMapReady(p0: GoogleMap?) {
        MapsInitializer.initialize(applicationContext)
        //LatLng class is google provided class to get latiude and longitude of location.
        //GpsTracker is helper class to get the details for current location latitude and longitude.
        //LatLng class is google provided class to get latiude and longitude of location.
        //GpsTracker is helper class to get the details for current location latitude and longitude.
        val location = LatLng(lat.toDouble(), longitude.toDouble())
        val map: GoogleMap? = p0
        map!!.addMarker(MarkerOptions().position(location).title("Marker position"))
        map.moveCamera(CameraUpdateFactory.newLatLng(location))
        map.mapType = GoogleMap.MAP_TYPE_NORMAL
    }*/
}