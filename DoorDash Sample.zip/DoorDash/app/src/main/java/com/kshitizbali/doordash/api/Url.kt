package com.kshitizbali.doordash.api

/**
 * A class to manager different URls other than the base Url.
 */
class Url {
    companion object {
        const val BASE_URL = "https://api.doordash.com/"
    }
}
