package com.kshitizbali.doordash.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kshitizbali.doordash.api.Repository
import com.kshitizbali.doordash.model.Restaurant

/**
 * Viewmodel for Restaurant detail activity
 */
class RestaurantViewModel() : ViewModel()/*, Repository.RestaurantInterface */ {
    var restName = MutableLiveData<String>()
    var cuisine = MutableLiveData<String>()
    var ratings = MutableLiveData<Float>()
    var offersPickup = MutableLiveData<String>()
    var offersDelivery = MutableLiveData<String>()
    var deliveryFee = MutableLiveData<String>()
    var deliveryTime = MutableLiveData<String>()
    var phoneNumber = MutableLiveData<String>()
    var address = MutableLiveData<String>()
    private var restDataMutableLiveData = MutableLiveData<Restaurant>()


    /**
     * Request the api for a specific restaurant.
     */
    fun getRestaurantDetails(restId: String, callbacks: Repository.RestaurantInterface) {
        Repository.getRestaurantById(restId, callbacks);
    }


    /**
     * Consume data after succesful fetch request from the Api
     */
    fun onRestFetched(data: Restaurant?) {
        restName.value = data?.name
        cuisine.value = data?.description
        ratings.value = data?.averageRating
        phoneNumber.value = data?.phoneNumber

        address.value = data!!.address!!.printableAddress
        if (data.isOffersPickup) {
            offersPickup.value = "Pick-Up"
        } else {
            offersPickup.value = "No Pick-Up"
        }
        if (data.isOffersDelivery) {
            offersDelivery.value = "Delivery"
        } else {
            offersDelivery.value = "No Delivery"
        }
        deliveryFee.value = "Delivery $".plus(data.deliveryFee.toString())
        if (data.isIsOnlyCatering) {
            deliveryTime.value = "Catering"
        } else {
            deliveryTime.value = "No Catering"
        }
        /*deliveryTime.value = "No Catering"data?.deliveryFeeDetails?.originalFee?.displayString*/
    }

    /* override fun onRestaurantDataFetched(data: Restaurant?) {
         restName.value = data?.name
         cuisine.value = data?.description
         ratings.value = data?.averageRating
         if (data?.isOffersPickup == true) {
             offersPickup.value = "Pick-Up"
         } else {
             offersPickup.value = "No Pick-Up"
         }
         if (data?.isOffersDelivery == true) {
             offersDelivery.value = "Delivery"
         } else {
             offersDelivery.value = "No Delivery"
         }
         deliveryFee.value = data?.deliveryFee.toString()
         deliveryTime.value = data?.deliveryFeeDetails?.originalFee?.displayString
         phoneNumber.value = data?.phoneNumber
     }*/

    /* interface CallRestaurantInterface {
         fun onCallRestaurant(phoneNo: String)
     }*/
}
