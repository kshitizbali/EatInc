package com.kshitizbali.doordash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.kshitizbali.doordash.databinding.ActivitySignupOrLoginBinding
import com.kshitizbali.doordash.model.SignUpUserModel
import com.kshitizbali.doordash.viewmodel.SignupViewModel

class SignUpLoginActivity : AppCompatActivity() {

    private lateinit var signupViewModel: SignupViewModel
    private lateinit var binding: ActivitySignupOrLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        signupViewModel = ViewModelProvider(this@SignUpLoginActivity).get(
            SignupViewModel::class.java
        )

        binding = DataBindingUtil.setContentView(
            this,
            R.layout.activity_signup_or_login
        )

        binding.lifecycleOwner = this
        binding.signupViewModel = signupViewModel

        signupViewModel.user?.removeObservers(this)
        signupViewModel.user?.observe(this,
            Observer<SignUpUserModel> { signupUserModel ->
                if (TextUtils.isEmpty(signupUserModel.strFirstName)) {
                    binding.atvFirstName.error = "Enter First Name"
                    binding.atvFirstName.requestFocus()
                } else if (TextUtils.isEmpty(signupUserModel.strLastName)) {
                    binding.atvLastName.error = "Enter Last Name"
                    binding.atvLastName.requestFocus()
                } else if (TextUtils.isEmpty(signupUserModel.strEmail)) {
                    binding.atvEmailId.error = "Enter a Valid Email Address"
                    binding.atvEmailId.requestFocus()
                } else if (!signupUserModel.isValidEmail) {
                    binding.atvEmailId.error = "Enter a Valid Email Address"
                    binding.atvEmailId.requestFocus()
                } /*else if (TextUtils.isEmpty(signupUserModel.strPhone)) {
                    binding.atvPhone.error = "Enter a Valid Email Address"
                    binding.atvPhone.requestFocus()
                }*/ else if (!signupUserModel.isValidPass) {
                    binding.atvPhone.error = "Enter a Valid Password"
                    binding.atvPhone.requestFocus()
                } else {
                    val handler = Handler()
                    binding.progressBar.visibility = View.VISIBLE
                    handler.postDelayed({ //Do something after 100ms
                        showCustomDialog(signupUserModel.strFirstName!!)
                        binding.progressBar.visibility = View.GONE
                    }, 400)
                }
            })


        val animFade = AnimationUtils.loadAnimation(
            this,
            R.anim.fade_in
        )
        val animFadeOut = AnimationUtils.loadAnimation(
            this,
            R.anim.fade_out
        )


        binding.btSignUp.setOnClickListener {
            if (binding.groupSignUp.visibility === View.GONE) {
                binding.groupWelcome.visibility = View.GONE
                binding.groupSignUp.visibility = View.VISIBLE
            }
        }


        binding.ivCancelSignup.setOnClickListener {
            if (binding.groupWelcome.visibility === View.GONE) {
                binding.groupSignUp.visibility = View.GONE
                binding.groupWelcome.visibility = View.VISIBLE

            }
        }

        /* Animation hyperspaceJump = AnimationUtils.loadAnimation(this, R.anim.hyperspace_jump);*/

        /* Animation hyperspaceJump = AnimationUtils.loadAnimation(this, R.anim.hyperspace_jump);*/
        binding.tvLoyInfoTitle.startAnimation(
            animFade
        )
        binding.btSignUp.startAnimation(animFade)
        binding.ivRestImage.startAnimation(animFade)

    }

    private fun showCustomDialog(fName: String) {
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView: View =
            LayoutInflater.from(this).inflate(R.layout.dialog_confirm, viewGroup, false)
        val tvStatusSubtext = dialogView.findViewById<View>(R.id.tvStatusSubtext) as TextView
        val buttonOk = dialogView.findViewById<View>(R.id.buttonOk) as Button
        tvStatusSubtext.text =
            String.format("%s %s", getString(R.string.welcome_to_the_family), fName)
        val builder = AlertDialog.Builder(this)
        builder.setView(dialogView)
        val alertDialog = builder.create()
        alertDialog.show()
        buttonOk.setOnClickListener {
            val i = Intent(this, HomeActivity::class.java)
            startActivity(i)
            alertDialog.dismiss()
            finish()
        }
    }
}