package com.kshitizbali.doordash

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.kshitizbali.doordash.adapter.RestaurantListAdapter
import com.kshitizbali.doordash.api.Repository
import com.kshitizbali.doordash.databinding.ActivityHomeBinding
import com.kshitizbali.doordash.model.RestaurantList
import com.kshitizbali.doordash.viewmodel.HomeViewModel

/**
 * Home activity which is the first screen the user interacts with after
 * signup. Also handles the restaurant list.
 */
class HomeActivity : AppCompatActivity(), Repository.RestaurantListInterface,
    RestaurantListAdapter.OnItemClickListener {

    private lateinit var homeViewModel: HomeViewModel
    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        homeViewModel = ViewModelProvider(this).get(
            HomeViewModel::class.java
        )

        binding = DataBindingUtil.setContentView(
            this,
            R.layout.activity_home
        )

        binding.lifecycleOwner = this
        binding.homeViewModel = homeViewModel



        showProgressBar()

        //WE can make this dynamic
        homeViewModel.getRestaurants("37.422740", "-122.139956", "0", "50", this)

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onItemClick(restId: String) {
        Log.i("onClick Rest ID", restId)
        val i = Intent(this, RestaurantDetailActivity::class.java)
        i.putExtra("REST_ID", restId)
        startActivity(i)
    }

    override fun onRestListFetched(data: RestaurantList?) {
        binding.rvRestaurants.adapter = RestaurantListAdapter(data!!, this)
        hideProgessBar()
    }
    private fun showProgressBar(){
        binding.progressBarRest.visibility = View.VISIBLE
    }

    private fun hideProgessBar(){
        binding.progressBarRest.visibility = View.GONE
    }

}