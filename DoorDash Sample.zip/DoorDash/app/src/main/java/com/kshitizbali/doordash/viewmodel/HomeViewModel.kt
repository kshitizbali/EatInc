package com.kshitizbali.doordash.viewmodel

import android.view.View
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kshitizbali.doordash.api.Repository
import com.kshitizbali.doordash.model.RestaurantList
import com.kshitizbali.doordash.model.SignUpUserModel

/**
 * View model for Home Activity.
 */
class HomeViewModel : ViewModel() {

    /**
     * This method is for creating a request for restaurant list
     */
    fun getRestaurants(
        lat: String,
        lng: String,
        offset: String,
        limit: String,
        callback: Repository.RestaurantListInterface
    ) {
        Repository.getRestaurantList(lat, lng, offset, limit, callback)
    }

    fun onClick(view: View?) {
        // TODO: 4/7/2021  
    }
}