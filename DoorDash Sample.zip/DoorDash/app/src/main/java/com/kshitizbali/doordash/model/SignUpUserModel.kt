package com.kshitizbali.doordash.model

import android.util.Patterns

/**
 * A model for signing up a user
 */
class SignUpUserModel(
    var strFirstName: String?,
    var strLastName: String?,
    var strEmail: String?,
    var strPhone: String?
) {
    val isValidEmail: Boolean
        get() = strEmail!!.isNotEmpty() && Patterns.EMAIL_ADDRESS.matcher(strEmail).matches()
    val isValidPass: Boolean
        get() = strPhone!!.isNotEmpty() && strEmail!!.length > 4
    val isValidPhone: Boolean
        get() = strPhone!!.length == 10 && Patterns.PHONE.matcher(strPhone).matches()
}